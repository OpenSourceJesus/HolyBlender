package com.sfb.standalonefilebrowser;

public interface StandaloneFileBrowserAndroidListener {
    void onFilesSelected(final String result);
}
